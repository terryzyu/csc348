#!/bin/bash
#This script just cleans and builds the code.....literally.
#I got lazy
ant clean
ant
