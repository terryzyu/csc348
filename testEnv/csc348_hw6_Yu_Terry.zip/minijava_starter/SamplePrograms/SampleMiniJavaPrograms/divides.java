public class divides {
	public static void main(String[] args) {
		int x = 4;
		int y = 2;
		double test = x / y;
		System.out.println(test);
	}
}